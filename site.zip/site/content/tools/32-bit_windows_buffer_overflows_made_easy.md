---
title: "32-Bit Windows Buffer Overflows Made Easy"
description: ""
url: "https://veteransec.com/2018/09/10/32-bit-windows-buffer-overflows-made-easy/"
category: "Miscellaneous"
---
