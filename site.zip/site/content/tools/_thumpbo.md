---
title: "@ThumpBo"
description: "感谢  师傅提出的建议，增加了读取指定TXT批量扫描敏感文件的功能 -df 并将扫描成功结果导出至 dumpout.txt 内"
url: "https://github.com/ThumpBo"
category: "Miscellaneous"
---
