---
title: "A Detailed Guide on OSCP Preparation – From Newbie to OSCP"
description: ""
url: "http://niiconsulting.com/checkmate/2017/06/a-detail-guide-on-oscp-preparation-from-newbie-to-oscp/"
category: "Miscellaneous"
---

