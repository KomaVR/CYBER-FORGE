---
title: "Active"
description: "Easy"
url: "https://app.hackthebox.com/machines/148"
category: "Miscellaneous"
---
