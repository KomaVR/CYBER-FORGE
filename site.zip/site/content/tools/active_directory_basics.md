---
title: "Active Directory Basics"
description: "TryHackMe

 - Easy
Post-Exploitation Basics - Easy
Vulnnet Roasted - Easy
Attacktive Directory - Medium
raz0r black - Medium
Enterprise - Medium
Vulnnet Active - Medium
Zero Logon - Hard
Holo - Hard
Throwback - Easy

"
url: "https://tryhackme.com/room/activedirectorybasics"
category: "Black Hat Tools"
---
