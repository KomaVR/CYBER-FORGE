---
title: "Agent Execution Quick Start Guide"
description: "Deploy an agent. See  for examples"
url: "https://merlin-c2.readthedocs.io/en/latest/quickStart/agent.html"
category: "Miscellaneous"
---
