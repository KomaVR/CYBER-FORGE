---
title: "Attacktive Directory"
description: "Medium"
url: "https://tryhackme.com/room/attacktivedirectory"
category: "Miscellaneous"
---
