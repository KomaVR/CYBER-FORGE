---
title: "Azure DevOps audit log"
description: "you can get the  using the Azure DevOps Services REST API, with a retention of 90 days. This log focuses on activities in Azure DevOps (related to an Azure DevOps organization)."
url: "https://learn.microsoft.com/en-us/azure/devops/organizations/audit/azure-devops-auditing?view=azure-devops&tabs=preview-page"
category: "Miscellaneous"
---
