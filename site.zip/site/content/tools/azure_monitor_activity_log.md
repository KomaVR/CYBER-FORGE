---
title: "Azure Monitor Activity log"
description: "you can get the  using the Az.Monitor PowerShell module, with a retention of 90 days. This log focuses on activities in Azure Resource Manager (related to an Azure subscription) ;"
url: "https://learn.microsoft.com/en-us/azure/azure-monitor/essentials/activity-log?tabs=powershell"
category: "Miscellaneous"
---
