---
title: "binary-security-check"
description: "check security of PE


 <bin>.exe

"
url: "https://github.com/koutheir/binary-security-check"
category: "Reverse Engineering"
---
