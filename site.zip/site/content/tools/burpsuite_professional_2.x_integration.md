---
title: "Burpsuite Professional 2.x integration"
description: ""
url: "https://github.com/1N3/Sn1per/wiki/Burpsuite-Professional-2.x-Integration"
category: "Web Exploitation"
---

