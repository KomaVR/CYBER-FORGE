---
title: "Code Review
        Manage code changes"
description: "
"
url: "https://github.com/features/code-review"
category: "Miscellaneous"
---

