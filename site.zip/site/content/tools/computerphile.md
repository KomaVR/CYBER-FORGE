---
title: "Computerphile"
description: "

Same people as Numberphile, but cooler. Makes really beginner-level and intuitive videos about basic concepts.

"
url: "https://www.youtube.com/user/Computerphile"
category: "Miscellaneous"
---
