---
title: "courses"
description: "Always doing free  and webcasts about security topics"
url: "https://www.antisyphontraining.com/pay-what-you-can/"
category: "Web Exploitation"
---
