---
title: "crc32fix"
description: "


fix height and width of png based on checksum

"
url: "https://github.com/Aloxaf/crc32fix"
category: "Miscellaneous"
---
