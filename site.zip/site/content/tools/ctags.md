---
title: "ctags"
description: ""
url: "https://github.com/universal-ctags/ctags"
category: "Miscellaneous"
---
