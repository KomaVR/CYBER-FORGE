---
title: "CyberChef"
description: "Web app for analysing and decoding data."
url: "https://gchq.github.io/CyberChef"
category: "Web Exploitation"
---
