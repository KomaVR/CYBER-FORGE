---
title: "Cybernetics"
description: "Advanced"
url: "https://app.hackthebox.com/prolabs/overview/cybernetics"
category: "Miscellaneous"
---
