---
title: "Dante"
description: "Beginner"
url: "https://app.hackthebox.com/prolabs/overview/dante"
category: "Miscellaneous"
---
