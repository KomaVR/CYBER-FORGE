---
title: "debootstrap"
description: "Root file system builder:

Powered by 
Automatic generation of file system that matches the kernels architecture
Ability to customize:

wanted packages in the file system
the Debian release version to base everything on



"
url: "https://wiki.debian.org/Debootstrap"
category: "Miscellaneous"
---
