---
title: "decode.gif"
description: "
Open the Command Palette (Ctrl+Shift+P) ➜ APKLab: Open an APK

"
url: "https://github.com/APKLab/APKLab/raw/master/assets/decode.gif"
category: "Miscellaneous"
---

