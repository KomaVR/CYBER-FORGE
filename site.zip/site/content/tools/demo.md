---
title: "Demo"
description: "ROPGadget

view gadgets & automatically generate ropchains
ROPgadget --ropchain --binary <binary>

You can then add padding at the start of the code (based on the difference between your buffer and return address) and run the code to get a shell




"
url: "https://www.youtube.com/watch?v=MSy0rdi1vbo&ab_channel=BenGreenberg"
category: "Reverse Engineering"
---
