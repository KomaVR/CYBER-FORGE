---
title: "detailed process auditing"
description: "Get processes running under a privileged account,  should be enabled:"
url: "https://docs.microsoft.com/en-us/windows-server/identity/ad-ds/manage/component-updates/command-line-process-auditing"
category: "Miscellaneous"
---
