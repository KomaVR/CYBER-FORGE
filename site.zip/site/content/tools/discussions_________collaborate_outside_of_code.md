---
title: "Discussions
        Collaborate outside of code"
description: "
"
url: "https://github.com/features/discussions"
category: "Miscellaneous"
---
