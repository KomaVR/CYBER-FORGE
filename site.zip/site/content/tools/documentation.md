---
title: "Documentation"
description: "[Doc]  updated to reflect the new changes.
All changes are immediate for consultancy / integrator license customers. The CE database will be available by the end of the month"
url: "https://vfeed.io/docs"
category: "Miscellaneous"
---
