---
title: "DVWA"
description: "Damn Vulnerable Web Application () is a PHP/MySQL web application that is damn vulnerable."
url: "http://dvwa.co.uk"
category: "Web Exploitation"
---
