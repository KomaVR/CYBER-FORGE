---
title: "EyeWitness"
description: "is designed to take screenshots of websites, provide some server header info, and identify default credentials if possible by @ChrisTruncer."
url: "https://github.com/ChrisTruncer/EyeWitness"
category: "Web Exploitation"
---
