---
title: "flaws.cloud"
description: "

Free challenges that involve finding secrets in S3, EC2, and Lambda

"
url: "https://flaws.cloud"
category: "Miscellaneous"
---

