---
title: "Foremost"
description: "Extract particular kind of files using headers.

apt-get install foremost

"
url: "http://foremost.sourceforge.net/"
category: "Miscellaneous"
---
