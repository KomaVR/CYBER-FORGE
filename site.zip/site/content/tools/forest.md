---
title: "Forest"
description: "HackTheBox

 - Easy
Active - Easy
Fuse - Medium
Cascade - Medium
Monteverde - Medium
Resolute - Medium
Arkham - Medium
Mantis - Hard
APT - Insane
Dante - Beginner
Offshore - Intermediate
RastaLabs - Intermediate
Cybernetics - Advanced
APT Labs - Advanced

"
url: "https://app.hackthebox.com/machines/212"
category: "Miscellaneous"
---
