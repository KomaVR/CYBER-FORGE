---
title: "Frida"
description: ""
url: "https://github.com/frida/frida/releases"
category: "Miscellaneous"
---
