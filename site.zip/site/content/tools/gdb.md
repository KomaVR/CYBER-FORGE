---
title: "gdb"
description: "

Binary analysis
peda (extension for increased functionality)
gef ( extension for pwners)

"
url: "https://www.gnu.org/software/gdb/"
category: "Reverse Engineering"
---
