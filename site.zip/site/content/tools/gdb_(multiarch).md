---
title: "GDB (multiarch)"
description: "Debugger:

Powered by  with either

GEF and GEF-extras, or
pwndbg


Allow users to specify GDB script in io/scripts/gdb_script to allow a scenario-tailored debugging experience

"
url: "https://sourceware.org/gdb/"
category: "Reverse Engineering"
---

