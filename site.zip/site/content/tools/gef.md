---
title: "GEF"
description: "Multi-Architecture GDB Enhanced Features for Exploiters & Reverse-Engineers."
url: "https://gef.readthedocs.io/en/latest/"
category: "Black Hat Tools"
---
