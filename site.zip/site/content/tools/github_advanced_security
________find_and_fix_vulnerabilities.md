---
title: "GitHub Advanced Security
        Find and fix vulnerabilities"
description: "
"
url: "https://github.com/security/advanced-security"
category: "Miscellaneous"
---

