---
title: "Hacksplaining"
description: "Interactive lessions for several well-known web vulnerabilities."
url: "https://www.hacksplaining.com/"
category: "Web Exploitation"
---
