---
title: "his website"
description: "CCSF professor that open sources all of his lectures and course material on"
url: "https://samsclass.info/"
category: "Web Exploitation"
---
