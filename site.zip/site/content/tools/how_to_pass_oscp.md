---
title: "How to Pass OSCP"
description: ""
url: "https://gist.github.com/unfo/5ddc85671dcf39f877aaf5dce105fac3"
category: "Miscellaneous"
---
