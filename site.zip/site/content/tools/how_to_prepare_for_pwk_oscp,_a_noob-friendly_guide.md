---
title: "How to prepare for PWK/OSCP, a noob-friendly guide"
description: ""
url: "https://www.abatchy.com/2017/03/how-to-prepare-for-pwkoscp-noob"
category: "Miscellaneous"
---

