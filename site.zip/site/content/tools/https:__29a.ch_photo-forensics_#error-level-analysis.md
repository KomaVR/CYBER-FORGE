---
title: "https://29a.ch/photo-forensics/#error-level-analysis"
description: "
Check if something was photoshopped (look at highlights)



"
url: "https://29a.ch/photo-forensics/#error-level-analysis"
category: "Malware Analysis"
---

