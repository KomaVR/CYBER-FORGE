---
title: "https://api.nuget.org/v3/index.json"
description: "Add a package source with the URL \"\""
url: "https://api.nuget.org/v3/index.json"
category: "Miscellaneous"
---

