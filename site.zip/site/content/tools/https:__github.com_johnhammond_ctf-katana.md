---
title: "https://github.com/JohnHammond/ctf-katana"
description: "Really good resource from John Hammond for different types of challenges:



"
url: "https://github.com/JohnHammond/ctf-katana"
category: "Password Cracking"
---

