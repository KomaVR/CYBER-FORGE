---
title: "https://habr.com/en/post/444940/"
description: "You can mount an image as a virtual machine



"
url: "https://habr.com/en/post/444940/"
category: "Miscellaneous"
---

