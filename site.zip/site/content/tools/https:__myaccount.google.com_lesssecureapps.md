---
title: "https://myaccount.google.com/lesssecureapps"
description: "Enable \"Allow less secure apps\" by going to"
url: "https://myaccount.google.com/lesssecureapps"
category: "Miscellaneous"
---

