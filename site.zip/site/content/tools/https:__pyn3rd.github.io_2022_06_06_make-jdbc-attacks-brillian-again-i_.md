---
title: "https://pyn3rd.github.io/2022/06/06/Make-JDBC-Attacks-Brillian-Again-I/"
description: ""
url: "https://pyn3rd.github.io/2022/06/06/Make-JDBC-Attacks-Brillian-Again-I/"
category: "Miscellaneous"
---

