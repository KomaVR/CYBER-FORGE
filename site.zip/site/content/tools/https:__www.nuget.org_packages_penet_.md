---
title: "https://www.nuget.org/packages/PeNet/"
description: "Custom Confirmatory DLL's :

These are DLL files which assist the tool to get the confirmation whether the DLL's are been successfully loaded from the identified hijack path
Compiled from the MalDLL project provided above (or use the precompiled binaries if you trust me!)
32Bit dll name should be: maldll32.dll
64Bit dll name should be: maldll64.dll
Install NuGet Package:** PeNet** ->  (Prereq while compiling the ImpulsiveDLLHijack project)

"
url: "https://www.nuget.org/packages/PeNet/"
category: "Miscellaneous"
---

