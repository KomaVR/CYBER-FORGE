---
title: "https://www.youtube.com/watch?v=gzLPVkZbaPA&ab_channel=MartinCarlisle"
description: "very good video on modifying the stack with fstring vuln and %n:



"
url: "https://www.youtube.com/watch?v=gzLPVkZbaPA&ab_channel=MartinCarlisle"
category: "Miscellaneous"
---

