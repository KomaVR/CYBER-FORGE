---
title: "https://academiadeforensedigital.com.br/treinamentos/treinamento-de-avilla-forensics/"
description: "(Gravado)"
url: "https://academiadeforensedigital.com.br/treinamentos/treinamento-de-avilla-forensics/"
category: "Malware Analysis"
---
