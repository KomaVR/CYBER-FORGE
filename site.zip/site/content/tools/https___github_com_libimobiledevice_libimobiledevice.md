---
title: "https://github.com/libimobiledevice/libimobiledevice"
description: "
Libimobiledevice:  (GNU GENERAL PUBLIC LICENSE). (FormIOS.cs)
"
url: "https://github.com/libimobiledevice/libimobiledevice"
category: "Miscellaneous"
---
