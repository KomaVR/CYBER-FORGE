---
title: "https://www.youtube.com/live/zQigjIIkBjQ?si=uanfwVUt33IqlWXt"
description: "
Android Forensics with Avilla Forensics - March 15th. 2022 - AFD ()
"
url: "https://www.youtube.com/live/zQigjIIkBjQ?si=uanfwVUt33IqlWXt"
category: "Malware Analysis"
---
