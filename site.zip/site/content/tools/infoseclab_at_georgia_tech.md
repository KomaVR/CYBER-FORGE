---
title: "InfoSecLab at Georgia Tech"
description: "

Good & advanced in-depth lectures on pwn
Requires some background knowledge

"
url: "https://www.youtube.com/channel/UCUcnLCrBVK9gS6ctEUVvkjA/featured"
category: "Miscellaneous"
---
