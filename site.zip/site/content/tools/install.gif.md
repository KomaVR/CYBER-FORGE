---
title: "install.gif"
description: "
Right-Click on .apk file (in dist directory) ➜ APKLab: Install the APK

"
url: "https://github.com/APKLab/APKLab/raw/master/assets/install.gif"
category: "Miscellaneous"
---

