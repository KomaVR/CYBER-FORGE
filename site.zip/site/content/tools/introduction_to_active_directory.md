---
title: "Introduction to Active Directory"
description: "HackTheBox Academy ( PAID )

 - Fundamental
ActiveDirectory LDAP - Medium
ActiveDirectory Powerview - Medium
ActiveDirectory BloodHound - Medium
ActiveDirectory Enumeration & Attacks - Medium

"
url: "https://academy.hackthebox.com/module/details/74"
category: "Miscellaneous"
---
