---
title: "jadx"
description: "and -gui

decompile apks

"
url: "https://github.com/skylot/jadx"
category: "Miscellaneous"
---
