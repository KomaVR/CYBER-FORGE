---
title: "jwt"
description: "

You can identify a JWT token since base64-encoded json (and thus  tokens) begins with \"ey\"
This site will decode JSON web tokens
You can crack the secret for the JSON web token to modify and sign your own tokens

echo <token> > .txt
john .txt



"
url: "https://jwt.io/"
category: "Web Exploitation"
---
