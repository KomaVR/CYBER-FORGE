---
title: "LearnPwn"
description: "For this one, I suggest looking at my  repo instead, as this cheatsheet was made before I knew much about pwn

However, I have included some notes amending to what I have here.

"
url: "https://github.com/Adamkadaban/LearnPwn"
category: "Miscellaneous"
---
