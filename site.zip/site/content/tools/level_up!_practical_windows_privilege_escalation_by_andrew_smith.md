---
title: "Level Up! Practical Windows Privilege Escalation by Andrew Smith"
description: ""
url: "https://www.youtube.com/watch?v=PC_iMqiuIRQ"
category: "Miscellaneous"
---

