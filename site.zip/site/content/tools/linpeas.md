---
title: "linpeas"
description: "

./.sh
Automatically looks for privilege escalation vectors

"
url: "https://github.com/carlospolop/privilege-escalation-awesome-scripts-suite/tree/master/linPEAS"
category: "Miscellaneous"
---
