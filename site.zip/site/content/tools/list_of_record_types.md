---
title: "List of record types"
description: "
Resolving DNS Errors

dig <site> <recordType>


Make sure you try TXT



"
url: "https://en.wikipedia.org/wiki/List_of_DNS_record_types"
category: "Miscellaneous"
---
