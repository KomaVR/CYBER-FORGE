---
title: "listener"
description: "Configure a"
url: "https://merlin-c2.readthedocs.io/en/latest/server/menu/listeners.html"
category: "Miscellaneous"
---
