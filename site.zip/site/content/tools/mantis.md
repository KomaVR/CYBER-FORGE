---
title: "Mantis"
description: "Hard"
url: "https://app.hackthebox.com/machines/98"
category: "Miscellaneous"
---
