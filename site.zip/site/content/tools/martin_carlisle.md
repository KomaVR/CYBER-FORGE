---
title: "Martin Carlisle"
description: "

Makes amazing writeup videos about the picoCTF challenges.

"
url: "https://www.youtube.com/user/carlislemc/featured"
category: "Miscellaneous"
---
