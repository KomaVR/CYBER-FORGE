---
title: "Matt Brown"
description: "

Embedded Security Pentester
Makes great beginner-friendly videos about IoT hacking

"
url: "https://www.youtube.com/@mattbrwn"
category: "Miscellaneous"
---
