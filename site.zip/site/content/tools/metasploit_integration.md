---
title: "Metasploit integration"
description: ""
url: "https://github.com/1N3/Sn1per/wiki/Metasploit-Integration"
category: "Miscellaneous"
---
