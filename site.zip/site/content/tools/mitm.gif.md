---
title: "mitm.gif"
description: "
Right-Click on or inside apktool.yml file ➜ APKLab: Prepare for HTTPS inspection

"
url: "https://github.com/APKLab/APKLab/raw/master/assets/mitm.gif"
category: "Miscellaneous"
---

