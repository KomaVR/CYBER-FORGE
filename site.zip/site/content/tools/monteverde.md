---
title: "Monteverde"
description: "Medium"
url: "https://app.hackthebox.com/machines/223"
category: "Miscellaneous"
---
