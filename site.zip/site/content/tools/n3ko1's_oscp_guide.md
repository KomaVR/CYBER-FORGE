---
title: "n3ko1's OSCP Guide"
description: ""
url: "http://www.lucas-bader.com/certification/2015/05/27/oscp-offensive-security-certified-professional"
category: "Miscellaneous"
---

