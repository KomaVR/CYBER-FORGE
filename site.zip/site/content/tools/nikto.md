---
title: "Nikto"
description: "(if allowed)

automatically looks for vulnerabilities

"
url: "https://tools.kali.org/information-gathering/nikto"
category: "Miscellaneous"
---
