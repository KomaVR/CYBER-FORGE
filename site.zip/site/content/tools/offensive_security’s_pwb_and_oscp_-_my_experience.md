---
title: "Offensive Security’s PWB and OSCP - My Experience"
description: "(+ some scripts)"
url: "http://www.securitysift.com/offsec-pwb-oscp/"
category: "Miscellaneous"
---

