---
title: "official docs"
description: "
quark-engine >=21.01.6 (for malware analysis)

Run quark in your Shell, if not found, check .

"
url: "https://github.com/quark-engine/quark-engine"
category: "Malware Analysis"
---
