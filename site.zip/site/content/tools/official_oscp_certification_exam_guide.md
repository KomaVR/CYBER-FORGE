---
title: "Official OSCP Certification Exam Guide"
description: ""
url: "https://help.offensive-security.com/hc/en-us/articles/360040165632-OSCP-Exam-Guide"
category: "Miscellaneous"
---
