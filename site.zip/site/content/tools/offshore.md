---
title: "Offshore"
description: "Intermediate"
url: "https://app.hackthebox.com/prolabs/overview/offshore"
category: "Miscellaneous"
---
