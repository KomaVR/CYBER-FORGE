---
title: "OSCP Goldmine"
description: ""
url: "http://0xc0ffee.io/blog/OSCP-Goldmine"
category: "Miscellaneous"
---
