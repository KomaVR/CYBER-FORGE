---
title: "OWASP Juice Shop"
description: "The  is an intentionally insecure webapp for security trainings written entirely in Javascript which encompasses the entire OWASP Top Ten and other severe security flaws."
url: "https://github.com/bkimminich/juice-shop"
category: "Web Exploitation"
---
