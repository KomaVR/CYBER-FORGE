---
title: "Part 1"
description: "Natural Advantages of Defense: What Military History Can Teach Network Security - , Part 2"
url: "https://www.schneier.com/crypto-gram/archives/2001/0415.html#1"
category: "White Hat Tools"
---
