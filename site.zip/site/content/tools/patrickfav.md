---
title: "patrickfav"
description: "for uber-apk-signer"
url: "https://github.com/patrickfav"
category: "Miscellaneous"
---
