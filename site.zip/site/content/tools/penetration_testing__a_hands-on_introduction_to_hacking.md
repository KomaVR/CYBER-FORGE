---
title: "Penetration Testing: A Hands-on Introduction to Hacking"
description: ""
url: "https://www.amazon.com/Penetration-Testing-Hands-Introduction-Hacking/dp/1593275641"
category: "Miscellaneous"
---
