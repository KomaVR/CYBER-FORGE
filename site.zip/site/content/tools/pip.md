---
title: "pip"
description: ": Package installer for Python"
url: "https://pip.pypa.io/en/stable/installation/"
category: "Miscellaneous"
---
