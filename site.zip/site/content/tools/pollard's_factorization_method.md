---
title: "Pollard's factorization method"
description: "Based on , which makes products of primes easy to factor if they are (B)smooth

This is the case if p-1 | B! and q - 1 has a factor > B

"
url: "http://www.math.columbia.edu/~goldfeld/PollardAttack.pdf"
category: "Miscellaneous"
---

