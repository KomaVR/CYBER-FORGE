---
title: "Privacy"
description: "

"
url: "https://docs.github.com/site-policy/privacy-policies/github-privacy-statement"
category: "Miscellaneous"
---
