---
title: "Process Monitor"
description: "In , select the Enable Boot Logging option."
url: "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon"
category: "Miscellaneous"
---
