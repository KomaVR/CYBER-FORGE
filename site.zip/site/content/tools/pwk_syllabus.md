---
title: "PWK Syllabus"
description: ""
url: "https://www.offensive-security.com/documentation/penetration-testing-with-kali.pdf"
category: "Miscellaneous"
---
