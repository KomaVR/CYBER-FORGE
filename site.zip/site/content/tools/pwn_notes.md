---
title: "pwn notes"
description: "

Notes from some random person online
Very surface-level, but good intro to everything

"
url: "https://ir0nstone.gitbook.io/notes/types/stack/ret2dlresolve"
category: "Miscellaneous"
---
