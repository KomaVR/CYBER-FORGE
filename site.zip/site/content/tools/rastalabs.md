---
title: "RastaLabs"
description: "Intermediate"
url: "https://app.hackthebox.com/prolabs/overview/rastalabs"
category: "Miscellaneous"
---
