---
title: "rebuild.gif"
description: "
Right-Click on or inside apktool.yml file ➜ APKLab: Rebuild the APK

"
url: "https://github.com/APKLab/APKLab/raw/master/assets/rebuild.gif"
category: "Miscellaneous"
---

