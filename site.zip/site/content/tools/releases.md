---
title: "Releases"
description: "Download the precompiled jar package from ."
url: "https://github.com/whwlsfb/BurpCrypto/releases"
category: "Miscellaneous"
---
