---
title: "Resolute"
description: "Medium"
url: "https://app.hackthebox.com/machines/220"
category: "Miscellaneous"
---
