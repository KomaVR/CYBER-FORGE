---
title: "ROPEmporium"
description: "

Set of challenges in every major architecture teaching Return-Oriented-Programming
Very high quality. Teaches the most basic to the most advanced techniques.
I'm currently adding my own writeups here

"
url: "https://ropemporium.com/"
category: "Miscellaneous"
---
