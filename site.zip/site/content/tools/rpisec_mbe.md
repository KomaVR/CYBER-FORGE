---
title: "RPISEC MBE"
description: "

RPI's Modern Binary Exploitation Course
Has a good amount of labs/projects for practice & some (slightly dated) lectures

"
url: "https://github.com/RPISEC/MBE"
category: "Black Hat Tools"
---
