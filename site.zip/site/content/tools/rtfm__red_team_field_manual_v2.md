---
title: "RTFM: Red Team Field Manual v2"
description: ""
url: "https://www.amazon.com/RTFM-Red-Team-Field-Manual/dp/1075091837"
category: "Miscellaneous"
---
