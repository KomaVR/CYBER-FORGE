---
title: "SBOM Input JSON File Format"
description: "
Multiple Queries (bulk/sbom)

(FREEMIUM) Bulk Input JSON File Format - puncia bulk <json-file> <output-directory>
{
    \"subdomain\": [
        \"domainA.com\",
        \"domainB.com\"
    ],
    \"replica\": [
        \"domainA.com\",
        \"domainB.com\"
    ],
    \"exploit\": [
        \"eoidentifierA\",
        \"eoidentifierB\"
    ],
    \"enrich\": [
        \"eoidentifierA\",
        \"eoidentifierB\"
    ]
}


(FREEMIUM)  - puncia sbom <json-file> <output-directory>

"
url: "https://github.com/CycloneDX/bom-examples/blob/master/SBOM/protonmail-webclient-v4-0912dff/bom.json"
category: "Black Hat Tools"
---
