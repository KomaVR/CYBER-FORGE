---
title: "seccomp-tools"
description: "check seccomp bpf


 dump ./<binary>

"
url: "https://github.com/david942j/seccomp-tools"
category: "Reverse Engineering"
---
