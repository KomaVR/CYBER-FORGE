---
title: "shellcheck"
description: "linter for shell scripts"
url: "https://github.com/koalaman/shellcheck"
category: "Miscellaneous"
---
