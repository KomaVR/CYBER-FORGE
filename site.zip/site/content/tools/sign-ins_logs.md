---
title: "sign-ins logs"
description: "Microsoft Entra  and audit logs."
url: "https://learn.microsoft.com/en-us/entra/identity/monitoring-health/concept-sign-ins"
category: "Miscellaneous"
---
