---
title: "Sql injection"
description: "

"
url: "https://github.com/Az0x7/vulnerability-Checklist/blob/main/Sql%20injection/sqlpayload.txt"
category: "Web Exploitation"
---
