---
title: "stacksmashing"
description: "

Amazing reverse engineering & hardware hacking videos
Has a really cool series of him reverse engineering WannaCry

"
url: "https://www.youtube.com/c/stacksmashing/videos"
category: "Miscellaneous"
---
