---
title: "Terms"
description: "

"
url: "https://docs.github.com/site-policy/github-terms/github-terms-of-service"
category: "Miscellaneous"
---
