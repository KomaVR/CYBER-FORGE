---
title: "The Hacker Playbook 3: Practical Guide to Penetration Testing"
description: ""
url: "https://www.amazon.com.au/Hacker-Playbook-Practical-Penetration-Testing/dp/1980901759"
category: "Miscellaneous"
---

