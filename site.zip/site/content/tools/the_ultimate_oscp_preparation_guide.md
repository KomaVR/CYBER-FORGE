---
title: "The Ultimate OSCP Preparation Guide"
description: ""
url: "https://johnjhacking.com/blog/the-oscp-preperation-guide-2020/"
category: "Miscellaneous"
---
