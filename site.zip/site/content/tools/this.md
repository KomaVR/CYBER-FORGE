---
title: "this"
description: "Least common mechanism - limit unnecessary sharing. see"
url: "https://dwheeler.com/secure-programs/Secure-Programs-HOWTO/minimize-data-access.html"
category: "Miscellaneous"
---
