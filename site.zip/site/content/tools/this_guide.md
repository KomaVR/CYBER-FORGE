---
title: "this guide"
description: "
If the public key is lost, follow  to recover it from YubiKey.
"
url: "https://www.nicksherlock.com/2021/08/recovering-lost-gpg-public-keys-from-your-yubikey/"
category: "Miscellaneous"
---
