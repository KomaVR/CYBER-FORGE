---
title: "TryHackMe"
description: "

Slightly easier boxes than HackTheBox
Step-by-step challenges
Now has \"learning paths\" to guide you through topics

"
url: "https://tryhackme.com/hacktivities"
category: "Miscellaneous"
---
