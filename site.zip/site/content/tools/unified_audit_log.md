---
title: "Unified Audit Log"
description: "Microsoft 365  ;"
url: "https://learn.microsoft.com/en-us/purview/audit-search?tabs=microsoft-purview-portal"
category: "Miscellaneous"
---
