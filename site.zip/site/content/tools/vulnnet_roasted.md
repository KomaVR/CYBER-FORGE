---
title: "Vulnnet Roasted"
description: "Easy"
url: "https://tryhackme.com/room/vulnnetroasted"
category: "Miscellaneous"
---
