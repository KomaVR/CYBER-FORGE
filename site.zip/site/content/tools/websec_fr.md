---
title: "websec.fr"
description: "

Lots of web challenges with a good range of difficulty

"
url: "http://websec.fr/#"
category: "Web Exploitation"
---
