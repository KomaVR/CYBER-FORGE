---
title: "Zero Logon"
description: "Hard"
url: "https://tryhackme.com/room/zer0logon"
category: "Miscellaneous"
---
